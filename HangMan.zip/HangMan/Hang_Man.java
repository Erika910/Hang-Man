import java.util.*;
/**
 * Write a description of class Hang_Man here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Hang_Man
{
    public static void main()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("What is your word or phrase?");
        String answer = s.nextLine();
        answer = answer.toLowerCase();
        System.out.println('\u000C');
        String underline = "";
        int count = 0;
        
        for(int i = 0; i < answer.length(); i++)
        {
            if(answer.charAt(i) == ' ')
            {
                underline += " ";
            }
            else
            {
                underline += "_";
            }
        }
        System.out.println(underline);
        char[] under = underline.toCharArray();
        
        while(underscoreCheck(under) && count < 7)
        {
            System.out.println("enter a letter");
            boolean right = false;

            String guess = s.next();
            for(int i = 0; i < answer.length(); i++)
            {
                if(guess.charAt(0) == answer.charAt(i))
                {
                    under[i] = answer.charAt(i);
                    right = true;
                }
            }
            
            if(right == false)
            {
                System.out.println("wrong");
                count ++;
            }
            
            if(count == 1)
            {
                System.out.println("--------------");
                System.out.println("|            |");
                System.out.println("|            |");
                System.out.println("|           ( )");
                System.out.println("|");
                System.out.println("|");
                System.out.println("|");
                System.out.println("--------------");
            }
            
            if(count == 2)
            {
                System.out.println("--------------");
                System.out.println("|            |");
                System.out.println("|            -");
                System.out.println("|           ( )");
                System.out.println("|            |");
                System.out.println("|            |");
                System.out.println("|");
                System.out.println("--------------");
            }
            
            if(count == 3)
            {
                System.out.println("--------------");
                System.out.println("|            |");
                System.out.println("|            -");
                System.out.println("|           ( )");
                System.out.println("|           /|");
                System.out.println("|            |");
                System.out.println("|");
                System.out.println("--------------");
            }
            
            if(count == 4)
            {
                System.out.println("--------------");
                System.out.println("|            |");
                System.out.println("|            -");
                System.out.println("|           ( )");
                System.out.println("|           /|\"");
                System.out.println("|            |");
                System.out.println("|");
                System.out.println("--------------");
            }
            
            if(count == 5)
            {
                System.out.println("--------------");
                System.out.println("|            |");
                System.out.println("|            -");
                System.out.println("|           ( )");
                System.out.println("|           /|\\");
                System.out.println("|            |");
                System.out.println("|           /");
                System.out.println("--------------");
            }
            
            if(count == 6)
            {
                System.out.println("--------------");
                System.out.println("|            |");
                System.out.println("|            -");
                System.out.println("|           ( )");
                System.out.println("|           /|\\");
                System.out.println("|            |");
                System.out.println("|           / \\");
                System.out.println("--------------");
            }
            
            if(count == 7)
            {
                System.out.println("You lost");
                System.out.println("--------------");
                System.out.println("|            |");
                System.out.println("|            -");
                System.out.println("|           (xx)");
                System.out.println("|           /|\\");
                System.out.println("|            |");
                System.out.println("|           / \\");
                System.out.println("--------------");
            }
            
            System.out.println(under);
        }
    }

    public static boolean underscoreCheck(char[] u)
    {
        for(char c: u)
        {
            if(c == '_')
                return true;
        }
        return false;
    }
}
